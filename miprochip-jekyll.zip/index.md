---
layout: default
title: Inicio
---

# Bienvenido a Miprochip Laboratory

Explora nuestros proyectos, ideas y soluciones en tecnología IoT.
