---
layout: default
title: Proyectos
permalink: /proyectos/
---

## Proyectos destacados

- 🔌 Cargador inteligente con Arduino  
- 🏠 Control de puerta IoT con ESP32  
- ⚡ Monitor INA219 con OLED  
