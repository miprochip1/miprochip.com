---
layout: default
title: Sobre mí
permalink: /sobre/
---

## Sobre mí

Soy un apasionado del IoT, automatización y tecnología embebida...
